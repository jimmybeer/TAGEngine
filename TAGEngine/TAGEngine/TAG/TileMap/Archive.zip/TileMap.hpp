#pragma once

// https://github.com/fallahn/sfml-tmxloader/tree/master/src

#include "Tileset.hpp"
#include "Layer.hpp"

#include "pugixml.hpp"

#include <string>
#include <list>
#include <vector>
#include <map>
#include <memory>
#include <array>
#include <bitset>

class SceneNode;


namespace tmx
{
    enum MapOrientation
    {
        Orthogonal,
        Isometric,
        SteppedIsometric
    };
}

namespace TagTiles
{

class TileMap
{
public:
    typedef std::unique_ptr<Layer> LayerPtr;

    TileMap(const TileMap&) = delete;
	TileMap& operator=(const TileMap&) = delete;
	
	TileMap();
	virtual ~TileMap();
	
	void add(LayerPtr layer, bool sort = true);
	void remove(Layer* layer);
	void remove(size_t index);
	
	size_t size()const;
	Layer* at(size_t index) const;
	void clear();
	
	unsigned int getTileWidth() const;
	unsigned int getTileHeight() const;
	unsigned int getNumCols() const;
	unsigned int getNumRows() const;
	unsigned int getMapWidth() const;
	unsigned int getMapHeight() const;
	
	sf::Vector2i mapPixelToCoords(float x, float y) const;
	sf::Vector2i mapPixelToCoords(const sf::Vector2f& pos) const;
	
	sf::Vector2f mapCoordsToPixel(int x, int y) const;
	sf::Vector2f mapCoordsToPixel(const sf::Vector2i& pos) const;
	
	virtual const sf::ConvexShape getShape() const = 0;
	/*
	virtual std::list<sf::Vector2i> getPath(const sf::Vector2i& origin, const sf::Vector2i dest) const = 0;
	virtual sf::Vecotr2i getPath1(const sf::Vector2i& origin, const sf::Vector2i& dest) const = 0;
	virtual int getDistance(const sf::Vector2i& origin, const sf::Vector2i& dest) const = 0;
	*/
    
	bool loadMap(const std::string& filename);
    void unLoad();
	
protected:
    void sortLayers();
	unsigned int mTileWidth;
	unsigned int mTileHeight;
	unsigned int mCols;
	unsigned int mRows;
	SceneNode* mParentNode;
	
private:
    bool parseMapNode(const pugi::xml_node& mapNode);
    bool parseTilesets(const pugi::xml_node& mapNode);
    bool parseLayer(const pugi::xml_node& layerNode);
    bool parseLayerProperties(const pugi::xml_node& propertiesNode, Layer& destLayer);
    bool processTiles(const pugi::xml_node& tilesetNode);
    
    void createDebugGrid();

	void draw(sf::RenderTarget& target, sf::RenderStates states, const sf::FloatRect& viewport) const;
	std::vector<std::unique_ptr<Layer>> mLayers;
    //std::map<std::string, std::unique_ptr<Tileset>> mTileSets;
    std::map<std::string, std::string> mProperties;
    
    std::vector<std::unique_ptr<sf::Texture>> mTilesetTextures;
    struct TileInfo // hold texture coords and tileset id of a tile
    {
        std::array<sf::Vector2f, 4> coords;
        sf::Vector2f size;
        sf::Uint16 tilesetId;
        TileInfo();
        TileInfo(const sf::IntRect& rect, const sf::Vector2f& size, sf::Uint16 tilesetId);
    };
    std::vector<TileInfo> mTileInfo; // stores information on all the tilesets for creating vertex arrays.
    
    // Caches loaded images to prevent loading the same tileset more than once
    sf::Image& loadImage(const std::string& imageName);
    std::map<std::string, std::shared_ptr<sf::Image>> mCachedImages;
    bool mFailedImage;
    
    bool decompress(const char* source, std::vector<unsigned char>& dest, int inSize, int expectedSize);
    std::string fileFromPath(const std::string& path);
    sf::Color colorFromHex(const char* hexStr) const;
};

//method for decoding base64 encoded strings
static std::string base64Decode(std::string const& string);
}