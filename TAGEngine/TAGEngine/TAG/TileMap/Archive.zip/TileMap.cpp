#include "TileMap.hpp"
#include "Logger.hpp"

#include "ResourcePath.hpp"

#include "SceneNode.hpp"
#include "Square.hpp"

#include <algorithm>
#include <sstream>
#include <cstring>
#include <zlib.h>
#include <utility>
#include <cassert>

namespace TagTiles
{

TileMap::TileMap()
 : mTileWidth(1u)
 , mTileHeight(1u)
 , mCols(1u)
 , mRows(1u)
 , mLayers()
 , mTilesetTextures()
 , mProperties()
 , mTileInfo()
 , mCachedImages()
 , mFailedImage(false)
{
    // reserve some space
    mLayers.reserve(5);
}

TileMap::~TileMap()
{
    clear();
}

unsigned int TileMap::getTileWidth() const
{
    return mTileWidth;
}

unsigned int TileMap::getTileHeight() const
{
    return mTileHeight;
}

unsigned int TileMap::getNumCols() const
{
    return mCols;
}

unsigned int TileMap::getNumRows() const
{
    return mRows;
}

unsigned int TileMap::getMapWidth() const
{
    return mCols * mTileHeight;
}

unsigned int TileMap::getMapHeight() const
{
    return mRows * mTileWidth;
}

void TileMap::add(LayerPtr layer, bool sort)
{
    //layer->mTileMap = this;
	//mLayers.push_back(std::move(layer))
	if(sort)
	{
	    sortLayers();
	}
}

void TileMap::remove(size_t index)
{
	mLayers.erase(mLayers.begin() + index);
}

void TileMap::remove(Layer* layer)
{
    auto found = std::find_if(mLayers.begin(), mLayers.end(), [&] (LayerPtr& p) { return p.get() == layer; });
	assert(found != mLayers.end());
	
	LayerPtr result = std::move(*found);
	//result->mTilemap = nullptr;
	//LayerPtr.erase(found);
	//return result;
}

size_t TileMap::size() const
{
    return mLayers.size();
}

Layer* TileMap::at(size_t index) const
{
    assert(index < mLayers.size());
	
    return mLayers.at(index).get();
}

void TileMap::clear()
{
    /*const size_t size = mLayers.size();
	for(size_t i = 0; i < size; ++i)
	{
	    delete(mLayers[i]);
	}*/
	mLayers.erase(mLayers.begin(), mLayers.end());
	
	mLayers.clear();
}

sf::Vector2i TileMap::mapPixelToCoords(const sf::Vector2f& pos) const
{
    return mapPixelToCoords(pos.x, pos.y);
}

sf::Vector2f TileMap::mapCoordsToPixel(const sf::Vector2i& pos) const
{
    return mapCoordsToPixel(pos.x, pos.y);
}

sf::Vector2i TileMap::mapPixelToCoords(float x, float y) const
{
    return sf::Vector2i(0,0);//Square::mapPixelToCoords(x, y, mTileSize);
}

sf::Vector2f TileMap::mapCoordsToPixel(int x, int y) const
{
    return sf::Vector2f(0.f,0.f);//Square::mapCoordsToPixel(x, y, mTileSize);
}

const sf::ConvexShape TileMap::getShape() const
{
    sf::ConvexShape shape;// = Square::getShape();
	shape.setScale(mTileWidth, mTileHeight);
    return shape;
}

void TileMap::sortLayers()
{
    std::sort(mLayers.begin(), mLayers.end(), [](LayerPtr& a, LayerPtr& b) -> bool
	            {
				    return a->z() < b->z();
			    });
	
	const size_t size = mLayers.size();
	for(size_t i = 0; i < size; ++i)
	{
	    mLayers[i]->sort();
	}
}

void TileMap::draw(sf::RenderTarget& target, sf::RenderStates states, const sf::FloatRect& viewport) const
{
    /*sf::FloatRect delta_viewport(viewport.left - mTileSize,
	                             viewport.top - mTileSize,
								 viewport.width + mTileSize * 2,
								 viewport.height + mTileSize * 2);
	const size_t size = mLayers.size();
	for(size_t i = 0; i < size; ++i)
	{
	    mLayers[i]->draw(target, states, delta_viewport);
	}*/
}
/*
template<typename GEOMETRY>
std::list<sf::Vector2i> Map<GEOMETRY>::getPath(const sf::Vector2i origin, const sf::Vector2i& dest) const
{
    int distance = getDistance(origin, dest);
	std::list<sf::Vector2i> res = origin:
	
	sf::Vector2f p(dest.x - origin.x,
	               dest.y - origin.y);
	float delta = 1.0/distance;
	float cumul = 0;
	res.emplace_back(origin);
	
	for(int i = 0; i < distance; ++i)
	{
	    sf::Vector2i pos = GEOMETRY::round(origin.x + p.x * cumul, origin.y + p.y * cumul);
		if(res.back() != pos)
		{
		    res.emplace_back(pos);
		}
		cumul += delta;
	}
	if(res.back() != dest)
    {
	    res.emplace_back(dest);
	}
	return res;
}

template<typename GEOMETRY>
sf::Vector2i Map<GEOMETRY>::getPath1(const sf::Vector2i origin, const sf::Vector2i& dest) const
{
    int distance = getDistance(origin, dest);
	sf::Vector2i res = origin:
	
	sf::Vector2f p(dest.x - origin.x,
	               dest.y - origin.y);
	float delta = 1.0/distance;
	float cumul = 0;
	for(int i = 0; i < distance; ++i)
	{
	    sf::Vector2i pos = GEOMETRY::round(origin.x + p.x * cumul, origin.y + p.y * cumul);
		if(pos != res)
		{
		    res = pos;
			break;
		}
		cumul += delta;
	}
	return res;
}

template<typename GEOMETRY>
int Map<GEOMETRY>::getDistance(const sf::Vector2i origin, const sf::Vector2i& dest) const
{
    return GEOMETRY::distance(origin.x, origin.y, dest.x, dest.y);
}*/

bool TileMap::loadMap(const std::string& filename)
{
    // parse map xml, return on error.
    pugi::xml_document mapDoc;
    pugi::xml_parse_result result = mapDoc.load_file(filename.c_str());
    if(!result)
    {
        LOG_ERR("Failed to open <" + filename);
        LOG_ERR("Reason: " + std::string(result.description()));
        return false;
    }
    
    // Set map properties
    pugi::xml_node mapNode = mapDoc.child("map");
    if(!mapNode)
    {
        LOG_ERR("Map node not found. Map <" + filename + "> not loaded.");
        return false;
    }
    
    if(!parseMapNode(mapNode)) return false;
    if(!parseTilesets(mapNode)) return false;
    
    // Traverse map node children and parse each layer.
    pugi::xml_node currentNode = mapNode.first_child();
    while(currentNode)
    {
        std::string name = currentNode.name();
        if(name == "layer")
        {
            if(!parseLayer(currentNode))
            {
                unLoad();
                return false;
            }
        }
        else if(name == "imagelayer")
        {
        }
        else if(name == "objectgroup")
        {
        }
        currentNode = currentNode.next_sibling();
    }
    
    createDebugGrid();
    
    LOG_INF("Parsed " + std::to_string(mLayers.size()) + " layers.");
    LOG_INF("Loaded <" + filename + "> successfully.");
    
    return true;
}

bool TileMap::parseMapNode(const pugi::xml_node& mapNode)
{
    if(!(mTileWidth = mapNode.attribute("tilewidth").as_int()) 
    || !(mTileHeight = mapNode.attribute("tileheight").as_int())
    || !(mCols = mapNode.attribute("width").as_int())
    || !(mRows = mapNode.attribute("height").as_int()))
    {
        LOG_ERR("Invalid tile size found, check map data. Map not loaded.");
        return false;
    }
	
	std::string orientation = mapNode.attribute("orientation").as_string();
	if(orientation != "orthogonal")
    {
        LOG_ERR("Map orientation " + orientation + " not currently supported. Map not loaded.");
        return false;
    }
    
    // parse any map properties
    if(pugi::xml_node propertiesNode = mapNode.child("properties"))
    {
        pugi::xml_node propertyNode = propertiesNode.child("property");
        while(propertyNode)
        {
            std::string name = propertyNode.attribute("name").as_string();
            std::string value = propertyNode.attribute("value").as_string();
            mProperties[name] = value;
            propertyNode = propertyNode.next_sibling("property");
            LOG_INF("Added map property " + name + " with value " + value); 
        }
    }
	
	return true;
}

bool TileMap::parseTilesets(const pugi::xml_node& mapNode)
{
    pugi::xml_node tileset;
    if(!(tileset = mapNode.child("tileset")))
    {
        LOG_WRN("No tilesets found.");
        return false;
    }
    LOG_INF("Caching image files, please wait...");
    
    // Empty vertex tile
    mTileInfo.push_back(TileInfo());
    
    // parse tile sets in order so GUIDs match index.
    while(tileset)
    {
        // if source attrib parse external tsx
        if(tileset.attribute("source"))
        {
            // try loading tsx
            std::string file = fileFromPath(tileset.attribute("source").as_string());
            std::string path = resourcePath() + file;
            
            pugi::xml_document tsxDoc;
            pugi::xml_parse_result result;
            
            result = tsxDoc.load_file(path.c_str());
            if(!result)
            {
                LOG_ERR("Failed to open external tsx doucment: " + path);
                LOG_ERR("Reason: " + std::string(result.description()));
                unLoad();
                return false;
            }
            
            // try parsing tileset node
            pugi::xml_node ts = tsxDoc.child("tileset");
            
            if(!processTiles(ts)) return false;
        }
        else // try for tmx map file data
        {
            if(!processTiles(tileset)) return false;
        }
        
        // move on to next tileset node
        tileset = tileset.next_sibling("tileset");
    }
    
    return true;
}
 
bool TileMap::processTiles(const pugi::xml_node& tilesetNode)
{ 
    sf::Uint16 tileWidth, tileHeight, spacing, margin;
    
    // try and parse tile sizes
    if(!(tileWidth = tilesetNode.attribute("tilewidth").as_int())
    || !(tileHeight = tilesetNode.attribute("tileheight").as_int()))
    {
        LOG_ERR("Invalid tileset data found. Map not loaded.");
        unLoad();
        return false;
    }
    spacing = (tilesetNode.attribute("spacing")) ? tilesetNode.attribute("spacing").as_int() : 0u;
    margin = (tilesetNode.attribute("margin")) ? tilesetNode.attribute("margin").as_int() : 0u;
    
    // try parsing image node
    pugi::xml_node imageNode;
    if(!(imageNode = tilesetNode.child("image")) || !imageNode.attribute("source"))
    {
        LOG_ERR("Missing image data in tmx file. Map not loaded.");
        unLoad();
        return false;
    }
    
    // process image from disk
    std::string imageName = fileFromPath(imageNode.attribute("source").as_string());
    sf::Image sourceImage = loadImage(imageName);
    if(mFailedImage)
    {
        LOG_ERR("Failed to load image " + imageName);
        return false;
    }
    
    // add transparency mask from colour if it exists
    if(imageNode.attribute("trans"))
        sourceImage.createMaskFromColor(colorFromHex(imageNode.attribute("trans").as_string()));
        
    // store image as a texture for drawing with vertex array
    std::unique_ptr<sf::Texture> tileset(new sf::Texture);
    tileset->loadFromImage(sourceImage);
    mTilesetTextures.push_back(std::move(tileset));

    // parse offset node if it exists - TODO store somewhere tileset info can be referenced
    sf::Vector2u offset;
    if(pugi::xml_node offsetNode = tilesetNode.child("tileoffset"))
    {
        offset.x = (offsetNode.attribute("x")) ? offsetNode.attribute("x").as_uint() : 0u;
        offset.y = (offsetNode.attribute("y")) ? offsetNode.attribute("y").as_uint() : 0u;
    }
    // TODO parse any tile properties and store with offset above
    
    // slice into tiles
    int columns = (sourceImage.getSize().x - 2u * margin + spacing) / (tileWidth + spacing);
    int rows = (sourceImage.getSize().y - 2u * margin + spacing) / (tileHeight + spacing);
    
    for(int y = 0; y < rows; y++)
    {
        for(int x = 0; x < columns; x++)
        {
            sf::IntRect rect; // must account for any spacing or margin on the tileset.
            rect.top = (y * (tileHeight + spacing)) + margin;
            rect.height = tileHeight;
            rect.left = (x * (tileWidth + spacing)) + margin;
            rect.width = tileWidth;
            
            // store texture coords and tileset index for vertex array
            mTileInfo.push_back(TileInfo(rect,
                sf::Vector2f(static_cast<float>(rect.width), static_cast<float>(rect.height)),
                mTilesetTextures.size() - 1u));
        }
    }
    
    LOG_INF("Processed " + imageName);
    return true;
}

bool TileMap::parseLayer(const pugi::xml_node& layerNode)
{	
    LOG_INF("Found standard map layer " + std::string(layerNode.attribute("name").as_string()));
    
    MapLayer layer(Layer);
    if(layerNode.attribute("name")) layer.name = layerNode.attribute("name").as_string();
    if(layerNode.attribute("opacity")) layer.opacity = layerNode.attribute("opacity").as_float();
    if(layerNode.attribute("visible")) layer.visible = layerNode.attribute("visible").as_bool();
    
    pugi::xml_node dataNode;
    if(!(dataNode = layerNode.child("data")))
    {
        LOG_ERR("Layer data missing or corrupt. Map not loaded.");
        return false;
    }
    
    // Decode and decomplress data first if necessary. See https://github.com/bjorn/tiled/wiki/TMX-Map-Format#data
	//for explanation of bytestream retrieved when using compression
    if(dataNode.attribute("encoding"))
    {
        std::string encoding = dataNode.attribute("encoding").as_string();
        std::string data = dataNode.text().as_string();
        
        if(encoding == "base64")
        {
            LOG_INF("Found Base64 encoded layer data, decoding ...");
            // remove any newlines or white space create by tab spaces in document.
            std::stringstream ss;
            ss << data;
            ss >> data;
            data = base64Decode(data);
            
            // clac the expected size of the uncompressed string
            int expectedSize = mCols * mRows * 4; // number of tiles * 4 bytes = 32 bits/tile
            std::vector<unsigned char> byteArray; // to hold decompressed data as bytes;
            byteArray.reserve(expectedSize);
            
            // check for compression (only used with base64 encoded data)
            if(dataNode.attribute("compression"))
            {
                std::string compression = dataNode.attribute("compression").as_string();
                LOG_INF("Found " + compression + " compressed layer data, decompressing...");
                
                // decompress with zlib
                int dataSize = data.length() * sizeof(unsigned char);
                if(!decompress(data.c_str(), byteArray, dataSize, expectedSize))
                {
                    LOG_ERR("Failed to decompress map data. Map not loaded.");
                    return false;
                }
            }
            else // uncompressed 
            {            
                byteArray.insert(byteArray.end(), data.begin(), data.end());    
            }
            
            //extract tile GIDs using bitshift (See https://github.com/bjorn/tiled/wiki/TMX-Map-Format#data) and add the tiles to layer
            sf::Uint16 x, y;
            x = y = 0;
            for(int i = 0; i < expectedSize - 3; i += 4)
            {
                sf::Uint32 tileGID = byteArray[i] | byteArray[i + 1] << 8 || byteArray[i + 2] << 16 | byteArray[i + 3] << 24;
                // resolve rotation
			    addTileToLayer(layer, x, y, tileGID);
                
                x++;
                if(x == mCols)
                {
                    x = 0;
                    y++;
                }
            }
        }
        else if(encoding == "csv")
        {
            LOG_INF("CSV encoded layer data found.");
            
            std::vector<sf::Uint32> tileGIDs;
            std::stringstream datastream(data);
            
            // parse csv string into vector of IDs
            sf::Uint32 i;
            while(datastream >> i)
            {
                tileGIDs.push_back(i);
                if(datastream.peek() == ',')
                    datastream.ignore();
            }
            
            // create tiles from IDs
            sf::Uint16 x, y;
            x = y = 0;
            unsigned int len = tileGIDs.size();
            for(int i = 0; i < len; i++)
            {
                // resolve rotation
			    addTileToLayer(layer, x, y, tileGID[i]);
                
                x++;
                if(x == mCols)
                {
                    x = 0;
                    y++;
                }
            }
        }
        else
        {
            LOG_ERR("Unsupported encoding of layer data found. Map not loaded.");
            return false;
        }
    }
    else // not encoded
    {
        LOG_INF("Found unencoded data.");
        pugi::xml_node tileNode;
        if(!(tileNode = dataNode.child("tile")))
        {
            LOG_ERR("No tile data found. Map not loaded.");
            return false;
        }
        
        sf::Uint16 x, y;
        x = y = 0;
        while(tileNode)
        {
            sf::Uint32 gid = tileNode.attribute("gid").as_uint();
            // resolve rotation
            
			addTileToLayer(layer, x, y, gid);
               
            x++;
            if(x == mCols)
            {
                x = 0;
                y++;
            }
        }
    }
    
    // parse any layer properties
    if(pugi::xml_node propertiesNode = layerNode.child("properties"))
        parseLayerProperties(propertiesNode, layer);
        
    // TODO convert layer tile coords to isometric if needed
    
    mLayers.push_back(layer);
    return true;
}

void TileMap::parseLayerProperties(const pugi::xml_node& propertiesNode, MapLayer& layer)
{
	pugi::xml_node propertyNode = propertiesNode.child("property");
	while(propertyNode)
	{
		std::string name = propertyNode.attribute("name").as_string();
		std::string value = propertyNode.attribute("value").as_string();
		layer.properties[name] = value;
		propertyNode = propertyNode.next_sibling("property");
		LOG_INF("Added layer property " + name + " with value " + value);
	}
}

void TileMap::createDebugGrid()
{
}
 
sf::Image& TileMap::loadImage(const std::string& imageName)
{
    const auto i = mCachedImages.find(imageName);
    if(i != mCachedImages.cend())
        return *i->second;
        
    // else attempt to load.
    std::shared_ptr<sf::Image> newImage = std::make_shared<sf::Image>();
    
    bool loaded = newImage->loadFromFile(imageName);
    if(!loaded)
    {
        newImage->create(20u, 20u, sf::Color::Yellow);
        mFailedImage = true;
    }
    
    mCachedImages[imageName] = newImage;
    return *mCachedImages[imageName];
}
   
std::string TileMap::fileFromPath(const std::string& path)
{
    assert(!path.empty());
    
    for(auto it = path.rbegin(); it != path.rend(); ++it)
    {
        if(*it == '/' || *it == '\\')
        {
            int pos = std::distance(path.rbegin(), it);
            return path.substr(path.size() - pos);
        }
    }
    return path;
}

sf::Color TileMap::colorFromHex(const char* hexStr) const
{
    // TODO proper checking valid string length
    unsigned int value, r, g, b;
    std::stringstream input(hexStr);
    input >> std::hex >> value;
    
    r = (value >> 16) & 0xff;
    g = (value >> 8) & 0xff;
    b = value & 0xff;
    
    return sf::Color(r, g, b);
}

bool TileMap::decompress(const char* source, std::vector<unsigned char>& dest, int inSize, int expectedSize)
{
	if(!source)
	{
		LOG_ERR("Input string is empty, decompression failed.");
		return false;
	}

	int currentSize = expectedSize;
	//TODO switch to std::make_unique when compatible with all compilers
	std::unique_ptr<unsigned char[]> byteArray(new unsigned char[expectedSize / sizeof(unsigned char)]);
	z_stream stream;
	stream.zalloc = Z_NULL;
	stream.zfree = Z_NULL;
	stream.opaque = Z_NULL;
	stream.next_in = (Bytef*)source;
	stream.avail_in = inSize;
	stream.next_out = (Bytef*)byteArray.get();
	stream.avail_out = expectedSize;

	if(inflateInit2(&stream, 15 + 32) != Z_OK)
	{
		LOG_ERR("inflate 2 failed");
		return false;
	}

	int result = 0;
	do
	{
		result = inflate(&stream, Z_SYNC_FLUSH);

		switch(result)
		{
		case Z_NEED_DICT:
		case Z_STREAM_ERROR:
			result = Z_DATA_ERROR;
		case Z_DATA_ERROR:
		case Z_MEM_ERROR:
			inflateEnd(&stream);
			LOG_ERR(std::to_string(result));
			return false;
		}

		if(result != Z_STREAM_END)
		{
			int oldSize = currentSize;
			currentSize *= 2;
			std::unique_ptr<unsigned char[]> newArray(new unsigned char[currentSize / sizeof(unsigned char)]);
			std::memcpy(newArray.get(), byteArray.get(), currentSize / 2);
			byteArray = std::move(newArray);
			
			stream.next_out = (Bytef*)(byteArray.get() + oldSize);
			stream.avail_out = oldSize;

		}
	}
	while(result != Z_STREAM_END);

	if(stream.avail_in != 0)
	{
		LOG_ERR("stream.avail_in is 0");
		LOG_ERR("zlib decompression failed.");
		return false;
	}

	const int outSize = currentSize - stream.avail_out;
	inflateEnd(&stream);

	std::unique_ptr<unsigned char[]> newArray(new unsigned char[outSize / sizeof(unsigned char)]);
	std::memcpy(newArray.get(), byteArray.get(), outSize);
	byteArray = std::move(newArray);

	//copy bytes to vector
	int length = currentSize / sizeof(unsigned char);	
	dest.insert(dest.begin(), &byteArray[0], &byteArray[length]);

	return true;
}


static const std::string base64Chars =
				"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
				"abcdefghijklmnopqrstuvwxyz"
				"0123456789+/";

static inline bool isBase64(unsigned char c)
{
	return (isalnum(c) || (c == '+') || (c == '/'));
}

static std::string base64Decode(std::string const& encoded_string)
{
	int in_len = encoded_string.size();
	int i = 0;
	int j = 0;
	int in_ = 0;
	unsigned char char_array_4[4], char_array_3[3];
	std::string ret;

	while (in_len-- && ( encoded_string[in_] != '=') && isBase64(encoded_string[in_]))
	{
		char_array_4[i++] = encoded_string[in_]; in_++;
		if (i ==4)
		{
			for (i = 0; i <4; i++)
				char_array_4[i] = base64Chars.find(char_array_4[i]);

			char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
			char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
			char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

			for (i = 0; (i < 3); i++)
				ret += char_array_3[i];
			i = 0;
		}
	}

	if (i)
	{
		for (j = i; j <4; j++)
			char_array_4[j] = 0;

		for (j = 0; j <4; j++)
			char_array_4[j] = base64Chars.find(char_array_4[j]);

		char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
		char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
		char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

		for (j = 0; (j < i - 1); j++)
			ret += char_array_3[j];
	}

	return ret;
}

}